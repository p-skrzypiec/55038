﻿function Get-ServiceRemote {

}
